%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-08T21:16:11-04:00*%
%TF.ProjectId,hall_breakout,68616c6c-5f62-4726-9561-6b6f75742e6b,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-08 21:16:11*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12RoundRect,0.250000X0.337500X0.475000X-0.337500X0.475000X-0.337500X-0.475000X0.337500X-0.475000X0*%
%ADD13C,1.500000*%
%ADD14R,1.050000X1.700000*%
%ADD15O,1.050000X1.700000*%
%ADD16C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X109539999Y-107600000D03*
D11*
X106999999Y-107600000D03*
X104459999Y-107600000D03*
%TD*%
D12*
%TO.C,C1*%
X108672500Y-101900000D03*
X106597500Y-101900000D03*
%TD*%
D13*
%TO.C,H2*%
X102400000Y-110600000D03*
%TD*%
D14*
%TO.C,U1*%
X108270000Y-104600000D03*
D15*
X107000000Y-104600000D03*
X105730000Y-104600000D03*
%TD*%
D16*
%TO.C,H1*%
X101800000Y-105000000D03*
%TD*%
D13*
%TO.C,H3*%
X111600000Y-110600000D03*
%TD*%
M02*
